# Ruby Sample Code

## Setup

* Install `ruby` and `rspec`
* Run `bundle install` from this directory

## Running Tests

* `rspec spec/<name_of_test>_spec.rb`
